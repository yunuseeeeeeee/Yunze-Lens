# Yunze Lens setup (all free, phone only)
1. GitHub: new PUBLIC repo. Create file `.github/workflows/build.yml` (paste the provided build.yml). Upload `project.zip`. Actions unpacks it and builds the APK (Actions tab > latest run > Artifacts).
2. Gemini key: aistudio.google.com > Get API key. Never share it in chat.
3. Cloudflare: Workers & Pages > Create Worker > paste `worker/worker.js` > Settings > Variables and Secrets > add secret `GEMINI_KEY`. Copy the worker URL.
4. Put that URL in `www/config.js` (edit on GitHub), then Actions > Run workflow.
