// Cloudflare Worker: holds the Gemini key (secret GEMINI_KEY) and rate-limits per IP.
const hits=new Map(),LIMIT=30;
const SYS=l=>`You are Yunze AI, the assistant inside the Yunze Lens shopping app, developed by the Yunze team. You run on a third-party AI model from Google. If asked which model you are, say so honestly; never claim to be your own model or deny it. Reply in ${l==='tr'?'Turkish':'English'}. Keep product names, brands and models in their original form. Be concise.`;
export default{async fetch(req,env){
const cors={'access-control-allow-origin':'*','access-control-allow-headers':'content-type','content-type':'application/json'};
if(req.method==='OPTIONS')return new Response(null,{headers:cors});
if(req.method!=='POST')return new Response('{}',{status:405,headers:cors});
const ip=req.headers.get('cf-connecting-ip')||'x',day=new Date().toISOString().slice(0,10)+ip,n=(hits.get(day)||0)+1;hits.set(day,n);
if(n>LIMIT)return new Response('{"error":"limit"}',{status:429,headers:cors});
const b=await req.json(),model=env.GEMINI_MODEL||'gemini-2.5-flash';
const url=`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
let body;
if(b.mode==='scan'){body={systemInstruction:{parts:[{text:SYS(b.lang)}]},contents:[{parts:[{inlineData:{mimeType:'image/jpeg',data:b.image}},{text:`Identify the main shopping product in this photo. Return JSON: {"name":string,"brand":string|null,"model":string|null,"found":boolean (true if exact brand/model identified),"summary":string (max 2 sentences),"verdict":string (one short worth-buying note),"query":string (best English store search query),"alternatives":[{"name":string,"why":string,"query":string}] (3 similar items)}`}]}],generationConfig:{responseMimeType:'application/json'}}}
else{body={systemInstruction:{parts:[{text:SYS(b.lang)+(b.product?` The user is looking at: ${b.product}.`:'')}]},contents:(b.messages||[]).slice(-12).map(m=>({role:m.role==='user'?'user':'model',parts:[{text:String(m.text).slice(0,2000)}]}))}}
const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':env.GEMINI_KEY},body:JSON.stringify(body)});
if(!r.ok)return new Response('{"error":"upstream"}',{status:502,headers:cors});
const j=await r.json(),txt=j.candidates?.[0]?.content?.parts?.[0]?.text||'';
return new Response(b.mode==='scan'?txt:JSON.stringify({reply:txt}),{headers:cors})}}
