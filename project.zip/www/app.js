const $=s=>document.querySelector(s),L=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},W=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const I={cam:'<svg viewBox="0 0 24 24"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',img:'<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/></svg>',his:'<svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/></svg>',chat:'<svg viewBox="0 0 24 24"><path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-6A8 8 0 1 1 21 12z"/></svg>',set:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/></svg>'};
let T={},lang=L('lang',(navigator.language||'en').startsWith('tr')?'tr':'en'),tab='home',cur=null,chat=[];
const t=k=>T[k]||k,esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const store=q=>{q=encodeURIComponent(q);return[['Amazon','https://www.amazon.com/s?k='+q],['AliExpress','https://www.aliexpress.com/wholesale?SearchText='+q],['eBay','https://www.ebay.com/sch/i.html?_nkw='+q],['Google Shopping','https://www.google.com/search?tbm=shop&q='+q]]};
async function load(){T=await (await fetch('lang/'+lang+'.json')).json();document.documentElement.lang=lang;const th=L('theme','auto');document.documentElement.dataset.theme=th==='auto'?'':th;go(tab==='res'?'home':tab)}
function nav(){$('#nav').innerHTML=[['home',I.cam,'home'],['hist',I.his,'history'],['chat',I.chat,'chat'],['set',I.set,'settings']].map(([k,i,l])=>`<button class="${tab===k?'on':''}" onclick="go('${k}')">${i}<span>${t(l)}</span></button>`).join('')}
function go(k){tab=k;nav();({home,hist,chat:chatV,set,res:resV}[k]||home)();$('#v').scrollTop=0}
function home(){const h=L('hist',[]).slice(0,4);$('#v').innerHTML=`<div class="hero"><div class="ring">${I.cam}</div><h1>Yunze Lens</h1><p class="sm" style="max-width:280px">${t('about')}</p></div>
<label class="btn">${I.cam}${t('scan')}<input type="file" accept="image/*" capture="environment" hidden onchange="pick(this)"></label><div style="height:8px"></div>
<label class="btn sec">${I.img}${t('gallery')}<input type="file" accept="image/*" hidden onchange="pick(this)"></label>
<h2>${t('recent')}</h2>${h.length?h.map(row).join(''):`<p class="sm">${t('noRecent')}</p>`}`}
const row=(x,i)=>`<div class="card item" onclick="open_(${i})"><img class="thumb" src="${x.img}"><div><b>${esc(x.name)}</b><div class="sm">${esc(x.brand||'')}</div></div></div>`;
function hist(){const h=L('hist',[]);$('#v').innerHTML=`<h1>${t('history')}</h1>${h.length?h.map(row).join('')+`<button class="sec" onclick="W('hist',[]);hist()">${t('clear')}</button>`:`<p class="sm">${t('emptyHist')}</p>`}`}
function open_(i){cur=L('hist',[])[i];go('res')}
function shrink(f,m){return new Promise(r=>{const im=new Image();im.onload=()=>{const k=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=im.width*k;c.height=im.height*k;c.getContext('2d').drawImage(im,0,0,c.width,c.height);r(c.toDataURL('image/jpeg',.8))};im.src=URL.createObjectURL(f)})}
async function pick(el){const f=el.files[0];if(!f)return;$('#v').innerHTML=`<div class="hero"><div class="spin"></div><p>${t('analyzing')}</p></div>`;
try{const img=await shrink(f,1024),thumb=await shrink(f,200);
const r=await fetch(window.YUNZE_PROXY,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({mode:'scan',lang,image:img.split(',')[1]})});
if(!r.ok)throw 0;const d=await r.json();cur={...d,img:thumb};const h=L('hist',[]);h.unshift(cur);W('hist',h.slice(0,30));go('res')}
catch{$('#v').innerHTML=`<div class="hero"><p>${t('error')}</p><br><button onclick="go('home')">${t('retry')}</button></div>`}}
function resV(){const x=cur;$('#v').innerHTML=`<img class="photo" src="${x.img}"><h1>${esc(x.name)}</h1><p class="sm">${esc([x.brand,x.model].filter(Boolean).join(' · '))}</p>
${x.found===false?`<div class="card sm" style="margin-top:8px">${t('notFound')}</div>`:''}<p style="margin:8px 0">${esc(x.summary)}</p><p class="sm">${esc(x.verdict||'')}</p>
<h2>${t('buy')}</h2><div class="stores">${store(x.query||x.name).map(([n,u],i)=>`<a class="btn ${i?'sec':'cta'}" href="${u}" target="_blank" rel="noopener">${n}</a>`).join('')}</div>
<h2>${t('alts')}</h2>${(x.alternatives||[]).map(a=>`<div class="card"><b>${esc(a.name)}</b><p class="sm">${esc(a.why)}</p><div class="stores">${store(a.query||a.name).slice(0,2).map(([n,u])=>`<a class="btn sec" href="${u}" target="_blank" rel="noopener">${n}</a>`).join('')}</div></div>`).join('')}
<div style="height:8px"></div><button onclick="chat=[];go('chat')">${I.chat}${t('ask')}</button>`}
function chatV(){$('#v').innerHTML=`<h1>Yunze AI</h1><div>${chat.length?'':`<p class="sm">${t('chatHint')}</p>`}${chat.map(m=>`<div class="msg ${m.role==='user'?'me':'ai'}">${esc(m.text)}</div>`).join('')}</div>
<div class="row" style="position:sticky;bottom:0;background:var(--bg);padding:8px 0"><input type="text" id="q" placeholder="${t('type')}"><button style="width:auto" onclick="send()">${t('send')}</button></div>`}
async function send(){const q=$('#q').value.trim();if(!q)return;chat.push({role:'user',text:q});chat.push({role:'model',text:'…'});chatV();
try{const r=await fetch(window.YUNZE_PROXY,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({mode:'chat',lang,product:cur&&cur.name,messages:chat.slice(0,-1)})});const d=await r.json();chat[chat.length-1].text=d.reply||t('error')}catch{chat[chat.length-1].text=t('error')}chatV()}
function set(){const th=L('theme','auto');$('#v').innerHTML=`<h1>${t('settings')}</h1><div class="card"><p class="sm">${t('language')}</p><select style="width:100%" onchange="lang=this.value;W('lang',lang);load()"><option value="en" ${lang==='en'?'selected':''}>English</option><option value="tr" ${lang==='tr'?'selected':''}>Türkçe</option></select></div>
<div class="card"><p class="sm">${t('theme')}</p><select style="width:100%" onchange="W('theme',this.value);load()">${['auto','light','dark'].map(k=>`<option value="${k}" ${th===k?'selected':''}>${t(k)}</option>`).join('')}</select></div><p class="sm">${t('about')}</p>`}
load();
