// Set this to your Cloudflare Worker URL after deploying (see SETUP.md)
window.YUNZE_PROXY = "https://yunze-lens.YOUR-NAME.workers.dev";
